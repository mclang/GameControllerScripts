Absolute Joystick input prototype for MWO.
Converts joystick input to mouse output

Read the instructions at the start of calibrate.ahk for setup instructions for each mech

Once you have the needed values for a given mech, you can paste them into AbsoluteJoy.ahk
AbsoluteJoy.ahk can be duplicated and renamed - ie you can have one version of it for each mech.